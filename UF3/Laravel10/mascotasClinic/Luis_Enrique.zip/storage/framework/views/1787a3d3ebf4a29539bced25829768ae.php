<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bienvenido al buscar mascotas del propietario</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP\UF3\Laravel10\mascotasClinic\resources\views/propietarios/buscarMascota.blade.php ENDPATH**/ ?>