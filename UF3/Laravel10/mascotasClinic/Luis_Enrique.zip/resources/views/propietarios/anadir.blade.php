@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Bienvenido al añadir Propietario</h1>
@endsection
