<?php

myHead('Listado de contactos');
?>

<body>
    <h1>Información del Contacto</h1>
    <?php echo $contacto ?>
    <p><a href="index.php">Volver al inicio</a></p>
</body>

</html>