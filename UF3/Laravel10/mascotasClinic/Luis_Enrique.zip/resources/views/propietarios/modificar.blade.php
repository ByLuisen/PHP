@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Bienvenido al Modificar Propietario</h1>
@endsection
