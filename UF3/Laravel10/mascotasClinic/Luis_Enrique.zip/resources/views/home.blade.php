@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Bienvenido al Home de Mascotas Clinic</h1>
@endsection
