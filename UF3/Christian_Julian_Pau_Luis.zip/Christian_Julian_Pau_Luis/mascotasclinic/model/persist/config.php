<?php

/**
 * Archivo que contine las credenciales a la base de datos 
 * @author Luis Enrique, Christian Sastre, Julian Ortega, Pau López 
 */

const CONSTDSN = "mysql:host=localhost;dbname=mascotasclinic";
const CONSTUSER = "m07";
const CONSTPASSWORD = "m07";





// //Config 2 
// /*
// $DSN = "mysql:host=localhost;dbname=mascotasclinic";
// $USER = "M07";
// $PASSWORD = "M07";
// */


