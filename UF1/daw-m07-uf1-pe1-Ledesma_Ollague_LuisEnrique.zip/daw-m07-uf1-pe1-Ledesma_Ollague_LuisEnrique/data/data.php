<?php
/**
 * @author Luis Enrique Ledesma Ollague
 * 
 * Fichero que contiene los datos de la página comprarEntradas.php
 */
$partidos = [
    'Barça vs AS Monaco',
    'Barça vs  Casademonst Zaragoza',
    'Barça vs Partizan Mozzart Bet',
    'Barça vs Río Breogán'
];

$zonas = [
    'ZONA 1 INFERIOR' => 114,
    'ZONA 1 SUPERIOR' => 95,
    'ZONA 2 INFERIOR' => 80,
    'ZONA 2 CENTRE' => 65
];