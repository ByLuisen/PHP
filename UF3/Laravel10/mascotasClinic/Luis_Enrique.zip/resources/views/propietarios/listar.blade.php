@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Bienvenido al listar Propietarios</h1>
@endsection
