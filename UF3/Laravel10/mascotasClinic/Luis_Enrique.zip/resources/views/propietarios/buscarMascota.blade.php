@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Bienvenido al buscar mascotas del propietario</h1>
@endsection
